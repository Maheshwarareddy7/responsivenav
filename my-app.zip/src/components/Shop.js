import React from "react";
import "./Shop.css";

const products = [
  { id: 1, name: "Homelander ", price: 20, description: "Super powerful", image: "homelander1.jpg" },
  { id: 2, name: "Thor ", price: 30, description: "God of thunder", image: "thor2.jpg" },
  { id: 3, name: "Omniman ", price: 25, description: "I will burn this planet down", image: "ominiman3.jpg" },
  { id: 4, name: "loki ", price: 25, description: "here is your saveyar", image: "loki4.jpg" },
  { id: 5, name: "superman ", price: 25, description: " do you bleed? men are brave.", image: "superman5.jpg" },
  { id: 1, name: "Homelander ", price: 20, description: "Super powerful", image: "homelander1.jpg" },
  { id: 2, name: "Thor ", price: 30, description: "God of thunder", image: "thor2.jpg" },
  { id: 3, name: "Omniman ", price: 25, description: "I will burn this planet down", image: "ominiman3.jpg" },
  { id: 4, name: "loki ", price: 25, description: "here is your saveyar", image: "loki4.jpg" },
  { id: 5, name: "superman ", price: 25, description: " do you bleed? men are brave.", image: "superman5.jpg" },
  { id: 1, name: "Homelander ", price: 20, description: "Super powerful", image: "homelander1.jpg" },
  { id: 2, name: "Thor ", price: 30, description: "God of thunder", image: "thor2.jpg" },
  { id: 3, name: "Omniman ", price: 25, description: "I will burn this planet down", image: "ominiman3.jpg" },
  { id: 4, name: "loki ", price: 25, description: "here is your saveyar", image: "loki4.jpg" },
  { id: 5, name: "superman ", price: 25, description: " do you bleed? men are brave.", image: "superman5.jpg" },
  { id: 1, name: "Homelander ", price: 20, description: "Super powerful", image: "homelander1.jpg" },
  { id: 2, name: "Thor ", price: 30, description: "God of thunder", image: "thor2.jpg" },
  { id: 3, name: "Omniman ", price: 25, description: "I will burn this planet down", image: "ominiman3.jpg" },
  { id: 4, name: "loki ", price: 25, description: "here is your saveyar", image: "loki4.jpg" },
  { id: 5, name: "superman ", price: 25, description: " do you bleed? men are brave.", image: "superman5.jpg" },

];

function Shop() {
  return (
    <div>

      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <h3>{product.name}</h3>
            <img src={product.image} alt={product.name} style={{ maxWidth: '1000px', maxHeight: '1000px' }} />
            <p>{product.description}</p>
            <p>${product.price}</p>
            <button>Add to Cart</button>
            <button>Buy</button>
          </li>
        ))}
      </ul>

    </div>
  );
}


export default Shop;
