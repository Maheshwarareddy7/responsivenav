import React, { useState } from 'react';
 import './Contact.css';

const Contact = ({ name, email, phone }) => {
  return (
    <div className="contact">
      <h2>{name}</h2>
      <p>Email: {email}</p>
      <p>Phone: {phone}</p>
    </div>
  );
};

const ContactForm = ({ addContact }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    addContact({ name, email, phone });
    setName('');
    setEmail('');
    setPhone('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Name:
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <br />
      <label>
        Email:
        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <br />
      <label>
        Phone:
        <input type="text" value={phone} onChange={(e) => setPhone(e.target.value)} />
      </label>
      <br />
      <button type="submit">Add Contact</button>
    </form>
  );
};

const ContactsApp = () => {
  const [contacts, setContacts] = useState([]);

  const addContact = (newContact) => {
    setContacts([...contacts, newContact]);
  };

  return (
    <div>
      <h1>Contact List</h1>
      <ContactForm addContact={addContact} />
      <div>
        {contacts.map((contact, index) => (
          <Contact key={index} {...contact} />
        ))}
        <p> terms and conditions?<br></br>
        "I accept the terms and conditions" is a correct and usable phrase in written English. You can use it when you are agreeing to the terms of a contract, a service, or a certain purchase. For example, "I accept the terms and conditions of this purchase and will pay the agreed-upon price.".
        </p>
      </div>
    </div>
  );
};

export default ContactsApp;

