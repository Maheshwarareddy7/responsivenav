 // Login.js
import React, { useState } from 'react';
import './Login.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Implement your authentication logic here
    // For simplicity, let's consider the login successful if both username and password are non-empty
    if (username && password) {
      alert('Login successful!');
    } else {
      alert('Invalid username or password.');
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <form>
        <label>
          Username:
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        </label>
        <br />
        <label>
          Password:
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <br />
        <button type="button" onClick={handleLogin}>Login</button>
      </form>
      <div> <p> 
        
Welcome to Guidance Residentials Customer Account Management Website
Existing customers will need to re-register on this website!
        </p></div>
     
    </div>
     
     
  );
};

export default Login;
