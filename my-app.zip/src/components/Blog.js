import React from "react";
import { Link } from "react-router-dom";
import "./Blog.css"

const blogPosts = [
  { id: 1, title: "React Basics", content: "Introduction to React" },
  { id: 2, title: "State Management", content: "Managing state in React" },
  { id: 3, title: "Component Lifecycle", content: "Understanding React component lifecycle" },
  
];

function Blog() {
  return (
    <div >
      <h2 style={{color:"red",fontSize:"20px"}}> Wellcome To  My Blog</h2>
      <p style={{color:"blue"}}>Here you can find articles about web development using React.<br></br>
      Each article is a self-contained lesson that covers a specific topic related to React.
Because React rendering can be triggered for many different reasons, it is best practice to wrap our commerce object method calls into a useEffect() hook. This hook acts as the replacment to componentWillMount() function when using class components. By leaving the second argument array empty, this method will run once before the initial render.

This allows you to safely store the response in state without triggering mulitple re-rendering. Using state (which is basically data storage) is a big part of React and if you look at this example - we are storing the returned data from the promise into state.Utilizing this object can be tricky in React (based on life cycle methods and how React renders components) because the methods or functions on the commerce object all return promises. The way you handle promises is similiar to how you handle API calls by using .then() and .catch() or try in order to process the data.

Because React rendering can be triggered for many different reasons, it is best practice to wrap our commerce object method calls into a useEffect() hook. This hook acts as the replacment to componentWillMount() function when using class components. By leaving the second argument array empty, this method will run once before the initial render.

This allows you to safely store the response in state without triggering mulitple re-rendering. Using state (which is basically data storage) is a big part of React and if you look at this example - we are storing the returned data from the promise into state.Utilizing this object can be tricky in React (based on life cycle methods and how React renders components) because the methods or functions on the commerce object all return promises. The way you handle promises is similiar to how you handle API calls by using .then() and .catch() or try in order to process the data.

Because React rendering can be triggered for many different reasons, it is best practice to wrap our commerce object method calls into a useEffect() hook. This hook acts as the replacment to componentWillMount() function when using class components. By leaving the second argument array empty, this method will run once before the initial render.

This allows you to safely store the response in state without triggering mulitple re-rendering. Using state (which is basically data storage) is a big part of React and if you look at this example - we are storing the returned data from the promise into state.
      </p>
      
      <ul>
        {blogPosts.map((post) => (
          <li key={post.id}>
            <h3>{post.title}</h3>
            <p>{post.content}</p>
            <Link to={`/blog/${post.id}`}>Read more</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Blog;
