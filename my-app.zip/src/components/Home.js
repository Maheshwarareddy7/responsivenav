import React from "react";


function Home() {
  const [bgcolor,setBgcolor]= React.useState('white')
  const handleButtonClick = () =>{
const newcolor = bgcolor  === 'white'? 'pink' : 'white'
setBgcolor(newcolor)

  }
   
  const profileDetails = {
    Name: "Maheshwara reddy",
    Title: "Software dev",
    Description: "working as a fronted dev.",
    Instagram: "https://www.instagram.com/maheshwarareddy_7?igsh=dmZ2MGlwNzlzb3J2"
  }
 

  return (
    
    <div className="App"  style={{backgroundColor:bgcolor}}> 
       
       <h1>Welcome to my app</h1>
       <header className='app-header'></header>
             <div className="profile-image-container">
        <img src="mahesh.jpg" alt="Profile" className="profile-image" />
      </div>
  
      <div className="content">
      <p ><b>Name:</b> {profileDetails.Name}</p>
        <p><b>Title:</b> {profileDetails.Title}</p>
        <p><b>Description:</b> {profileDetails.Description}</p>

    <button  className="my-button" onClick={handleButtonClick}>change  color</button><br>
    </br>
    
    
    <p><b>follow on instagram</b></p>
    <a href={profileDetails.Instagram} target="_blank" rel="noopener noreferrer"> 
  <i className="fab fa-instagram"></i>
  <div className="instagram-logo-container">
          <img src=" instalogo.png" alt="Instagram" className="instagram-logo" />
        </div>
  <span className='instagram-span'>  Instagram </span>
</a>
 
   
    </div>
    
    </div>
  );
}
 


 
 


export default Home;

