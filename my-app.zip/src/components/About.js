import React from "react";
 


const aboutStyles = {
  fontFamily: 'Arial, sans-serif',
  backgroundColor: '#e6e6e6',
  color: 'red',
  padding: '20px',
  maxWidth: '800px',
  margin: '0 auto',
};
function About() {
  return <div style={aboutStyles}>About Page Content
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Suspendisse in dolor viverra, cursus arcu finibus, sollicitudin dolor.
In malesuada ligula hendrerit nisi semper mollis.
Quisque sit amet enim eu quam ultrices ultricies.
Nulla mattis elit et dolor hendrerit sollicitudin.
Aliquam malesuada nisl at eros porttitor vestibulum.
Nunc molestie turpis eu eleifend ornare.
Integer ultricies neque ac justo laoreet, venenatis semper justo ultricies.
Proin ac nibh et orci varius consectetur.
Donec quis risus finibus, volutpat neque id, laoreet nibh.
Suspendisse malesuada lectus in felis luctus commodo.
Vestibulum dignissim magna non leo tincidunt euismod.
Phasellus fermentum ante ut pretium placerat.
Nullam faucibus orci ac lacus dictum suscipit.
Praesent at nisi ullamcorper ante aliquet fermentum id sed dolor.
Vestibulum at augue id lacus cursus pulvinar.
Ut ut arcu a ligula auctor tempor nec quis libero.
Integer volutpat lectus eget mollis gravida.
Proin sed ante eget libero tempor elementum.
Praesent dictum turpis in ligula pellentesque efficitur.</p>
  </div>;
}

export default About;
