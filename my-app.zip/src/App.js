 
import React from 'react'; 
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import './App.css';
import Navbar from './components/Navbar';
import Home from "./components/Home"; 
import Blog from "./components/Blog";
import Shop from "./components/Shop";
import About from "./components/About";
import Contact from "./components/Contact";
import Login from './components/Login';


 alert( "wellcome to my app." )
function App() {
  
  return (
    
    <div className="App" >
  
   <Router>
   <Navbar/>
      <Routes>
        <Route  exact path="/Home" element={<Home />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/shop" element={<Shop />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />}/>
      </Routes>
    </Router>
      
       
      
     
        
     
 
   
    </div>
    
    
  );
}
 


 
export default App;
